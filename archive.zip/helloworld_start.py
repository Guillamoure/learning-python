def main():
	print("Hello World")

# if you are running this file from the terminal
# and you have this condition
# the function will run
if __name__ == "__main__":
	main()
